package com.proyecto.cuidadoconelgato;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etUsuarioLog, etContraseñaLog;

    Button btLogin, btRegistrarse;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsuarioLog = findViewById(R.id.etUsuarioLog);
        etContraseñaLog = findViewById(R.id.etContraseñaLog);
        btLogin = findViewById(R.id.btLogin);
        btRegistrarse = findViewById(R.id.btRegistrarse);

        base_de_datos bdHelper = new base_de_datos(MainActivity.this);
        SQLiteDatabase db = bdHelper.getWritableDatabase();

        Cursor cursorDatos = null;

        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etContraseñaLog.getText().toString().equals("1234")){
                    Intent cliente = new Intent(MainActivity.this, precliente.class);
                    startActivity(cliente);
                }
                else if((etUsuarioLog.getText().toString().equals("audel"))&&(etContraseñaLog.getText().toString().equals("audel"))){
                    Intent op = new Intent(MainActivity.this, activity_op.class);
                    startActivity(op);
                }


            }
        });

        btRegistrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    Intent registro = new Intent(MainActivity.this, activity_registro.class);
                    startActivity(registro);
            }
        });


    }
    /*


    public void metIniciar(View view) {


        String bUsuario = etUsuarioLog.getText().toString();
        String bContraseña = etContraseñaLog.getText().toString();

        String dato="123";
        /*Cursor fila = bd.rawQuery("select contraseña from persona where usuario=" +bUsuario, null);

        if (fila.moveToFirst())
            dato = fila.getString(0);



        if (dato.equals(bContraseña)){
            Intent inicio = new Intent(MainActivity.this, activity_cliente.class);
            startActivity(inicio);

            if(bUsuario.equals("audel")){
                Intent ventanaOP = new Intent(MainActivity.this, activity_op.class);
                startActivity(ventanaOP);
            }

        } else
            Toast.makeText(this, "Parece que el usuario no ha sido registrado...", Toast.LENGTH_SHORT).show();

        bd.close();
    }
    */
    public void metRegistrarse(View view){
        Intent registro = new Intent(MainActivity.this, activity_registro.class);
        startActivity(registro);
    }
}
package com.proyecto.cuidadoconelgato;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class activity_cliente extends AppCompatActivity {

    ImageView ivCodigoQR;
    Button btQR;
    ImageView regresar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente);

        ivCodigoQR = findViewById(R.id.ivCodigoQR);
        btQR = findViewById(R.id.btQR);
        VideoView mivideo = findViewById(R.id.video);
        regresar = findViewById(R.id.regresar);

        String videop = "android.resource://" + getPackageName() + "/" + R.raw.uno;
        Uri uri = Uri.parse(videop);
        mivideo.setVideoURI(uri);

        MediaController mediaController = new MediaController(this);
        mivideo.setMediaController(mediaController);
        mediaController.setAnchorView(mivideo);

        regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    public void generarQR (View view){

        Toast.makeText(this, "Producto añadido", Toast.LENGTH_LONG).show();


    }
    public void cesta(View view){
        Intent c = new Intent(activity_cliente.this, cesta.class);
        startActivity(c);
    }
}
package com.proyecto.cuidadoconelgato;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class activity_op extends AppCompatActivity {

    Button btScan;
    EditText etDatos, etDatosPersona;
    ImageView imagen, imagenPersona;
    ImageView regresar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_op);

        btScan = findViewById(R.id.btScan);
        etDatos = findViewById(R.id.etDatos);
        etDatosPersona = findViewById(R.id.etDatosPersona);
        imagenPersona = findViewById(R.id.imagenPersona);
        imagen = findViewById(R.id.imagen);
        regresar = findViewById(R.id.regresar);

        regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });




        btScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                IntentIntegrator integrador = new IntentIntegrator(activity_op.this);
                integrador.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
                integrador.setPrompt("Lector - CDP");
                integrador.setCameraId(0);
                integrador.setBeepEnabled(true);
                integrador.setBarcodeImageEnabled(true);
                integrador.initiateScan();


            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() == null) {
                Toast.makeText(this, "Cencelado", Toast.LENGTH_LONG).show();
            } else {

                Toast.makeText(this, "Escaneado: " + result.getContents(), Toast.LENGTH_LONG).show();
                etDatos.setText(" " + result.getContents());
                imagen.setImageResource(R.drawable.camisa);
                imagenPersona.setImageResource(R.drawable.audel);
                etDatosPersona.setText("Audel\n qudel2002@gmail.com");
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

}
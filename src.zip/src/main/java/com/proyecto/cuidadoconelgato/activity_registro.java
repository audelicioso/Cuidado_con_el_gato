package com.proyecto.cuidadoconelgato;

import static com.proyecto.cuidadoconelgato.R.id.etCorreoReg;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


public class activity_registro extends AppCompatActivity{


    EditText etUsuarioReg, etContraseñaReg, etCorreoReg,etContraseñaRegConf;

    ImageView regresar;

    Button btCrear, btFoto;

    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        etUsuarioReg= findViewById(R.id.etUsuarioReg);
        etContraseñaReg= findViewById(R.id.etContraseñaReg);
        etCorreoReg= findViewById(R.id.etCorreoReg);
        etContraseñaRegConf= findViewById(R.id.etContraseñaRegConf);
        btCrear= findViewById(R.id.btCrear);
        btFoto = findViewById(R.id.btFoto);
        regresar = findViewById(R.id.regresar);

        btCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etContraseñaReg.getText().toString().equals(etContraseñaRegConf.getText().toString())){
                    insersion dbInsersion = new insersion(activity_registro.this);
                    long id = dbInsersion.insetarDato(etUsuarioReg.getText().toString(),etContraseñaReg.getText().toString(),etCorreoReg.getText().toString());
                    if(id>0){
                        Toast.makeText(activity_registro.this,"REGISTRO GUARDADO",Toast.LENGTH_LONG).show();
                        limpiar();
                    }else{
                        Toast.makeText(activity_registro.this,"ERROR AL GUARDAR",Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(activity_registro.this,"Revise la contraseña...",Toast.LENGTH_LONG).show();

                }
            }
        });

        btFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c = new Intent(activity_registro.this, camara.class);
                startActivity(c);
            }
        });

        regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    private void limpiar(){
        etUsuarioReg.setText(""); etContraseñaReg.setText(""); etCorreoReg.setText(""); etContraseñaRegConf.setText("");

    }


    /*
    public void metRegistro(View view){
        base_de_datos bdHelper = new base_de_datos(activity_registro.this);
        SQLiteDatabase bd = bdHelper.getWritableDatabase();

        if(db != null){

        }

        String nombre = etNombre.getText().toString();
        String usuario = etUsuarioReg.getText().toString();
        String contraseña = etContraseñaReg.getText().toString();


        ContentValues registro = new ContentValues();

        registro.put("usuario", usuario);
        registro.put("contraseña", contraseña);
        registro.put("nombre", nombre);
        registro.put("apellido", apellido);
        registro.put("direccion", direccion);
        registro.put("cp", cp);



        // los inserto en la base de datos
        bd.insert("persona", null, registro);

        bd.close();

        Toast.makeText(this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();

        // ponemos los campos a vacío para insertar el siguiente usuario
        limpiar();

        Intent regreso = new Intent(activity_registro.this, MainActivity.class);

        startActivity(regreso);


    }


    public void limpiar(){
        etDireccion.setText(""); etCP.setText(""); etUsuarioReg.setText(""); etContraseñaReg.setText("");

    }
    */

}
package com.proyecto.cuidadoconelgato;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class cesta extends AppCompatActivity {

    ImageView imagen, ivCodigoQR;
    EditText etDatos;
    ImageView regresar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cesta);

        etDatos = findViewById(R.id.etDatos);
        imagen = findViewById(R.id.imagen);
        ivCodigoQR = findViewById(R.id.ivCodigoQR);
        regresar = findViewById(R.id.regresar);

        etDatos.setText("Camisa Mexico Retro 1998 \n precio: $750 \n tallas: M, CH, G");
        imagen.setImageResource(R.drawable.camisa);

        regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }


    public void generarQR (View view){

        Toast.makeText(this, "Producto añadido", Toast.LENGTH_LONG).show();

        String pedido="Camisa Mexico Retro 1998 \n precio: $750 \n tallas: M, CH, G";
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.encodeBitmap(
                    pedido,
                    BarcodeFormat.QR_CODE,
                    750,
                    750);
            ivCodigoQR.setImageBitmap(bitmap);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
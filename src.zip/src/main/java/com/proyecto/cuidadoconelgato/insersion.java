package com.proyecto.cuidadoconelgato;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class insersion extends base_de_datos{

    Context context;

    public insersion(Context context) {
        super(context);
        this.context = context;
    }
    public long insetarDato(String usuario,String contraseña,String correo){

        long id=0;

        try{

            base_de_datos dbHelper = new base_de_datos(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("usuario", usuario);
            values.put("contraseña", contraseña);
            values.put("correo", correo);

            id = db.insert(TABLE_PERSONA, null, values);



        }catch (Exception ex){
            ex.toString();
        }
        return id;

    }
}

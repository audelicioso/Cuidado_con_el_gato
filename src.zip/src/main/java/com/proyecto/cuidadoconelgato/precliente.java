package com.proyecto.cuidadoconelgato;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class precliente extends AppCompatActivity {

    Button cesta, comprar, tienda;
    ImageView descuento;
    ImageView regresar;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_precliente);
        cesta = findViewById(R.id.btCesta);
        comprar = findViewById(R.id.btComprar1);
        descuento= findViewById(R.id.imgDescuento);
        tienda = findViewById(R.id.ubicacion);
        regresar = findViewById(R.id.regresar);


        descuento.setImageResource(R.drawable.descuento);


        regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    public void cesta(View view){
        Intent c = new Intent(precliente.this, cesta.class);
        startActivity(c);
    }
    public void compra(View view){
        Intent compra = new Intent(precliente.this, activity_cliente.class);
        startActivity(compra);
    }
    public void gps(View view) {
        Intent g = new Intent(precliente.this, GPS.class);
        startActivity(g);
    }
}